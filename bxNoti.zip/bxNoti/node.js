
NodeCache = require('node-cache'),
linkfy = require('linkifyjs')

abrir = {}
abrir.NodeCache = NodeCache
abrir.linkfy = linkfy
module.exports = abrir