while :
do
clear
node index.js
done