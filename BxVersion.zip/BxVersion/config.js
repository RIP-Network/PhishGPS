const fs = require('fs')
const chalk = require('chalk')

global.travaSend = '10'
global.owner = ['5512981966384']
global.packname = 'By'
global.author = 'bruxo'
global.prefa = ['','!','.',',']
global.sessionName = './lib/qrcode'
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})